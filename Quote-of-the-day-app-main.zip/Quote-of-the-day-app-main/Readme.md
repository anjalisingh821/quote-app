### Quote of the Day App

This is a simple app which displays random quotes.

### Technologies Used
-HTML 5

-CSS

-Javascript

### Links
Solution URL - https://github.com/Ishita-gup123/Quote-of-the-day-app.git

Live Site URL - https://quotei.netlify.app/
